/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package blackjack;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author icway
 */
public class PauseMenuFrenchTest {
    
    public PauseMenuFrenchTest() {
    }
    
    @Before
    public void setUpClass() {
    }
    
    @After
    public void tearDownClass() {
    }

    //==========================================================================
    // Tests
    //==========================================================================
    
    /**
     * Test frenchPauseTitle, of class PauseMenuFrench
     */
    @Test
    public void pauseTitle() {
        //Test
        System.out.println("Test French Pause Title method");
        PauseMenuFrench menu = new PauseMenuFrench();
        String expResult = "Pause";
        menu.frenchPauseTitle();
        String result = "Pause";
        assertEquals (expResult, result);
    }
    
}
