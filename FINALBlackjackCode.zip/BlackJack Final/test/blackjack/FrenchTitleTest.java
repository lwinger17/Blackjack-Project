/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package blackjack;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author icway
 */
public class FrenchTitleTest {
    
    public FrenchTitleTest() {
    }
    
    @Before
    public void setUpClass() {
    }
    
    @After
    public void tearDownClass() {
    }
    
    //==========================================================================
    // Tests
    //==========================================================================
    
    /**
     * Test frenchTitleName, of class FrenchTitle
     */
    @Test
    public void frenchTitleName() {
        //Test
        System.out.println("Test French Title Name method");
        FrenchTitle menu = new FrenchTitle();
        String expResult = "Blackjack";
        menu.frenchTitleName();
        String result = "Blackjack";
        assertEquals (expResult, result);
    }
    
}
